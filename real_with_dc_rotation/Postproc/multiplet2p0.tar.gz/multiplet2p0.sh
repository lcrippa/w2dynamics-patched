#! /bin/bash
# Requires pgf/tikz and pdflatex to be installed.
# $ sudo aptitude install pgf
# $ sudo aptitude install pdflatex

# unset variable
unset string
# get the eigenvalues and multiplicity from output of Operator.exe
read -p "Type in the result file name: " fname
# get maximal occupation:
n_max=$(grep 'Nt=' $fname|sort -nk 4|tail -1|sed 's/^ *//;s/ *$//;s/ \{1,\}/ /g'|cut -d ' ' -f4|cut -d' ' -f4)
echo
echo $n_max" is the maximum occupation."
echo
# read occupation defining the configuration
read -p "Type in total number of electrons Nt: " nt 
[ $nt -ne 0 -o $nt -eq 0 ] 2>/dev/null
if [ $? -ne 0 ] || [ $nt -gt $n_max ] || [ $nt -lt 1 ]; then
   echo "Invalid occupation number, allowed values are: 1,...,"$n_max
   echo "Exiting program."
   exit 666
fi
# function returns list of eigenvalues
get_ev()
{
  nt=$1 
  fname=$2
  grep 'Nt=           '$nt $fname|colrm 1 41|sed 's/^ *//;s/ *$//;s/ \{1,\}/ /g'|tr -s ' ' \\n|sed 's/^\([0-9]\+\.[0-9]\{0,3\}\).*/\1/'|sort
}
# get the number of different eigenvalues
emax=$(get_ev $nt $fname|uniq|wc -l)
for (( e=1; e<=emax; e++ ));do
  #get eigenvalue in line e
  ev=$(get_ev $nt $fname|uniq|sed -n ${e}p)
  #get multiplicity of eigenvalue in line e
  g=$(get_ev $nt $fname|grep -c ${ev})
  #build string for TikZ 
  string=$string,$ev\\/$g
done
# removing the first comma
string=$(echo $string|sed 's/.\(.*\)/\1/')
ymin=$(get_ev $nt $fname|uniq|sed -n 1p)
ymin=$(echo "scale=0; ${ymin}/1"|bc)
ymax=$(get_ev $nt $fname|uniq|sed -n ${emax}p)
ymax=$(echo "scale=0; ${ymax}/1+1"|bc)
# use the template for LaTeX/TikZ 
N=$nt-1
sed "s/#mtp#/${string}/g;s/#ymin#/${ymin}/g;s/#ymax#/${ymax}/g" multiplet.tpl > ${fname}_${nt}.tex 
pdflatex ${fname}_${nt}.tex>/dev/null
rm -rf ${fname}_${nt}.aux ${fname}_${nt}.log
echo
echo "Multiplet diagram written in ${fname}_${nt}.pdf."
echo
exit 0
